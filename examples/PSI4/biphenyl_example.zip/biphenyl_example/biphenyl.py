#!/usr/bin/env python
"""
ROSE example: biphenyl in cc-pVDZ, localized on atomic IAO fragments that are
then collected into two recanonization groups, one per phenyl ring.

The atomic fragments are NOT recomputed here.  They are taken from a library of
DIRAC-generated non-relativistic cc-pVDZ atoms, which avoids the symmetry
breaking that an open-shell atomic SCF without fractional occupations produces.
ROSE finds them by nuclear charge, as <Z>.h5, so biphenyl needs 001.h5 and
006.h5.  The reference basis of the atoms need not match the basis of the
molecule.

The two rings are defined by a labelled xyz file: an ordinary xyz with a fifth
column naming the group each center belongs to.  The group that appears first
in that file (phenyl1) is the one that takes the severed C-C bond.

The last step writes two Molden files, MOLECULE.molden (canonical Hartree-Fock)
and ribo.molden (the ROSE orbitals), so that the first thing to do with the
result is to look at it and compare the two.

Run it either in its own directory or from a separate working directory; the
input files are staged into whichever directory you start it in:

    python /path/to/biphenyl.py
"""

from genibo_MOcoeff import *
import os
import shutil
import subprocess
import sys
import psi4

#--------------------------------------------------------------------------
#------------------------------- LOCATIONS --------------------------------
#--------------------------------------------------------------------------
# The example and the fragment library can be moved anywhere; adjust these two
# variables, or set the matching environment variables, once they have moved.

example_directory = os.path.dirname(os.path.abspath(__file__))
atomfrag_library  = os.environ.get("ROSE_ATOMFRAG_LIBRARY",
                                   os.path.join(example_directory, "NONREL_cc-pVDZ"))
xyz_directory     = os.environ.get("ROSE_XYZ_DIRECTORY", example_directory)

rose_directory    = os.environ.get("ROSEDIR")
if rose_directory is None:
   sys.exit("ROSEDIR is not set; point it at the ROSE installation")
rose_executable   = os.path.join(rose_directory, "bin", "rose.x")
molden_converter  = os.environ.get("ROSE_NPY2MOLDEN",
                                   os.path.join(rose_directory, "test", "npy2molden.py"))
run_directory     = os.getcwd()

#--------------------------------------------------------------------------
#------------------------------ THE SYSTEM --------------------------------
#--------------------------------------------------------------------------

xyz_file     = os.path.join(xyz_directory, "biphenyl.xyz")
groups_file  = os.path.join(xyz_directory, "biphenyl_groups.xyz")
groups_local = "biphenyl_groups.xyz"   # name ROSE sees in the run directory

basis        = "cc-pVDZ"
charge       = 0
multiplicity = 1
exponent     = 4    # Knizia's IBO functional; ROSE itself defaults to 2 (Pipek-Mezey)

psi4.set_memory("4 GB")
psi4.set_num_threads(4)

with open(xyz_file) as f:
   f.readline()
   f.readline()
   geometry = [(line.split()[0], tuple(line.split()[1:4])) for line in f if line.strip()]

molecule = moldata(geometry=geometry,
                   charge=charge,
                   multiplicity=multiplicity,
                   data_directory=run_directory)

#--------------------------------------------------------------------------
#------------------ ATOMIC FRAGMENTS AND GROUP DEFINITION -----------------
#--------------------------------------------------------------------------

def stage(source, name):
   """Copy an input file into the run directory under the name ROSE expects.

   The run directory may be the directory the file already lives in -- running
   the example in place is the obvious thing to do -- so copying a file onto
   itself is not an error, it just means there is nothing to do.
   """
   if not os.path.isfile(source):
      sys.exit("could not find " + source)
   target = os.path.join(run_directory, name)
   if os.path.exists(target) and os.path.samefile(source, target):
      return
   shutil.copyfile(source, target)


for z in sorted(set(molecule.protons)):
   stage(os.path.join(atomfrag_library, "{:03d}.h5".format(z)), "{:03d}.h5".format(z))

stage(groups_file, groups_local)

#--------------------------------------------------------------------------
#------------------------------ ROSE INPUT --------------------------------
#--------------------------------------------------------------------------
# Only the non-default keywords.  Leaving .NFRAGMENTS out is what selects
# atomic fragments, and the standalone build already defaults to .FILE_FORMAT
# h5, localized occupied and virtual orbitals, and valence + hard virtuals.

with open("INPUT_GENIBO", "w") as f:
   f.write("**ROSE\n")
   f.write(".EXPONENT\n")
   f.write(str(exponent) + "\n")
   f.write(".FRAGMENT_XYZ\n")
   f.write(groups_local + "\n")
   f.write("*END OF INPUT\n")

#--------------------------------------------------------------------------
#--------------------------- SCF ON THE MOLECULE --------------------------
#--------------------------------------------------------------------------

print("Starting Psi4 calculation, should take no more than a few minutes.")
molecule, scf_wfn = run_psi4_mocoeff(molecule,
                                     basis=basis,
                                     save=True,
                                     uncontract=True)

# ROSE reads the supermolecule from CHECKPOINT.h5 and writes its results back
# into copies of it (iao.h5, ribo.h5).  MOLECULE.npy keeps the psi4 archive.
subprocess.check_call("mv -f {}.h5  CHECKPOINT.h5".format(molecule.name), shell=True, cwd=run_directory)
subprocess.check_call("mv -f {}.xyz MOLECULE.XYZ".format(molecule.name),  shell=True, cwd=run_directory)
subprocess.check_call("mv -f {}.npy MOLECULE.npy".format(molecule.name),  shell=True, cwd=run_directory)

#--------------------------------------------------------------------------
#------------------------- IAO/IBO CONSTRUCTION ---------------------------
#--------------------------------------------------------------------------

with open(os.path.join(run_directory, "rose.out"), "w") as rose_output:
    subprocess.check_call(rose_executable, shell=True, cwd=run_directory,
                          stdout=rose_output, stderr=subprocess.STDOUT)
print("ROSE output written to rose.out")

#--------------------------------------------------------------------------
#------------------------- STORE IBO WAVEFUNCTION -------------------------
#--------------------------------------------------------------------------

nmo = replace_psi4_MOcoefficients(scf_wfn, 'ribo')
print("Wrote {:d} localized and recanonized orbitals to ribo.h5 / ribo.npy".format(nmo))

#--------------------------------------------------------------------------
#--------------------------- MOLDEN FILES ---------------------------------
#--------------------------------------------------------------------------
# ROSE stores its orbitals as coefficient matrices in hdf5, which no viewer
# reads.  What a viewer needs instead is the AO basis written out explicitly,
# primitive by primitive, in exactly the order the coefficient columns assume.
# Getting that order wrong does not fail loudly -- it silently draws the wrong
# orbital -- so the basis and the coefficients must come from one and the same
# object.  psi4 can do that: replace_psi4_MOcoefficients has just written the
# ROSE coefficients into a psi4 wavefunction archive (ribo.npy), and psi4 can
# rebuild the basis from it and emit both blocks together.
#
# npy2molden.py wraps that call and repairs two things psi4 cannot know from a
# restored archive: the occupation numbers (an archive carries none, so psi4
# writes zeros for every orbital) and, for an ROHF reference, a duplicated beta
# block that doubles the apparent orbital count.
#
# Two files are written, and the comparison between them is the point of the
# exercise:
#
#   MOLECULE.molden  the canonical Hartree-Fock orbitals, delocalized over the
#                    whole molecule, ordered by orbital energy
#   ribo.molden      the ROSE orbitals: occupied first and then virtuals, each
#                    localized on one phenyl ring and recanonized within it
#
# In ribo.molden the energies restart at every group boundary and so are NOT
# monotonic down the file.  That is correct and is what grouping means here;
# a viewer that re-sorts the orbitals by energy will scramble the two rings
# back together.

if not os.path.isfile(molden_converter):
   print("skipping the Molden step: no converter at " + molden_converter)
else:
   for archive in ("MOLECULE", "ribo"):
      subprocess.check_call([sys.executable, molden_converter, archive + ".npy",
                             "--quiet"], cwd=run_directory)
   print("Orbitals written in Molden format to eanble visualization.")
